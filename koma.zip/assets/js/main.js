document.addEventListener("DOMContentLoaded", () => {
  // Pastikan Firebase sudah siap
  if (typeof firebase === "undefined" || !firebase.firestore) {
    console.error("Firebase tidak terinisialisasi dengan benar.");
    // Tampilkan pesan error yang lebih jelas di halaman jika Firebase gagal dimuat
    document.body.innerHTML =
      "<h1>Error Kritis: Firebase Gagal Dimuat. Periksa koneksi internet dan file firebase-config.js</h1>";
    return;
  }
  const db = firebase.firestore();

  const formatRupiah = (number) =>
    new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(number);

  /*=============== THEME & INTERACTIVITY SETUP ===============*/
  const body = document.body;

  // Efek hanya untuk desktop
  if (window.matchMedia("(min-width: 769px)").matches) {
    const home = document.getElementById("home");
    const kopiPanel = document.querySelector(".kopi-panel");
    const matchaPanel = document.querySelector(".matcha-panel");
    const cursorGlow = document.querySelector(".cursor-glow");

    if (home && kopiPanel && matchaPanel) {
      kopiPanel.addEventListener("mouseenter", () =>
        home.classList.add("hover-kopi")
      );
      kopiPanel.addEventListener("mouseleave", () =>
        home.classList.remove("hover-kopi")
      );
      matchaPanel.addEventListener("mouseenter", () =>
        home.classList.add("hover-matcha")
      );
      matchaPanel.addEventListener("mouseleave", () =>
        home.classList.remove("hover-matcha")
      );
    }

    if (cursorGlow) {
      window.addEventListener("mousemove", (e) => {
        cursorGlow.style.left = `${e.clientX}px`;
        cursorGlow.style.top = `${e.clientY}px`;
      });
    }
  }

  /*=============== DYNAMIC PRODUCTS ===============*/
  const productsContainer = document.querySelector(".products__container");
  const renderProducts = async (filter = "all") => {
    if (!productsContainer) return;
    productsContainer.innerHTML =
      '<p class="loading-text">Memuat produk...</p>';
    try {
      const snapshot = await db.collection("products").orderBy("name").get();
      productsContainer.innerHTML = "";
      if (snapshot.empty) {
        productsContainer.innerHTML =
          '<p class="info-text">Belum ada produk.</p>';
        return;
      }
      snapshot.forEach((doc) => {
        const product = { id: doc.id, ...doc.data() };
        if (filter === "all" || product.category === filter) {
          const card = document.createElement("article");
          card.className = "products__card";
          card.dataset.id = doc.id;
          card.dataset.name = product.name;
          card.dataset.price = product.price;
          card.dataset.imageUrl = product.imageUrl;
          card.innerHTML = `
            <div class="products__images">
              <img src="${product.imageUrl}" alt="${
            product.name
          }" class="products__coffee" />
            </div>
            <div class="products__data">
              <h3 class="products__name">${product.name.toUpperCase()}</h3>
              <span class="products__price">${formatRupiah(
                product.price
              )}</span>
            </div>
            <div class="products__buttons">
              <button class="button products__button-action choose-options-btn">Pilih Opsi</button>
            </div>`;
          productsContainer.appendChild(card);
        }
      });
      if (productsContainer.innerHTML === "") {
        productsContainer.innerHTML = `<p class="info-text">Tidak ada produk di kategori ini.</p>`;
      }
    } catch (error) {
      console.error("Error fetching products: ", error);
      productsContainer.innerHTML =
        '<p class="error-text">Gagal memuat produk.</p>';
    }
  };

  /*=============== CART & MODAL LOGIC ===============*/
  const cart = document.getElementById("cart");
  const cartContent = document.getElementById("cart-content");
  const customizationModal = document.getElementById("customization-modal");
  let cartItems = JSON.parse(localStorage.getItem("kopiMatchaCart")) || [];
  let currentProductForModal = {};

  const saveCart = () =>
    localStorage.setItem("kopiMatchaCart", JSON.stringify(cartItems));
  const showCart = () => {
    cart.classList.add("show-cart");
    body.style.overflow = "hidden";
  };
  const hideCart = () => {
    cart.classList.remove("show-cart");
    body.style.overflow = "auto";
  };

  const showNotification = (message) => {
    const notification = document.createElement("div");
    notification.classList.add("notification");
    notification.innerText = message;
    body.appendChild(notification);
    setTimeout(() => notification.classList.add("show"), 10);
    setTimeout(() => {
      notification.classList.remove("show");
      setTimeout(() => body.removeChild(notification), 500);
    }, 2000);
  };

  const flyToCart = (targetElement) => {
    const cartIcon = document.getElementById("cart-icon");
    if (!cartIcon || !targetElement) return;
    const cartRect = cartIcon.getBoundingClientRect();
    const targetRect = targetElement.getBoundingClientRect();
    const flyingEl = document.createElement("img");
    flyingEl.src = targetElement.src;
    flyingEl.className = "fly-to-cart-animation";
    body.appendChild(flyingEl);

    flyingEl.style.left = `${targetRect.left + targetRect.width / 2}px`;
    flyingEl.style.top = `${targetRect.top + targetRect.height / 2}px`;
    flyingEl.style.width = `${targetRect.width}px`;
    flyingEl.style.height = `${targetRect.height}px`;

    requestAnimationFrame(() => {
      flyingEl.style.left = `${cartRect.left + cartRect.width / 2}px`;
      flyingEl.style.top = `${cartRect.top + cartRect.height / 2}px`;
      flyingEl.style.width = "20px";
      flyingEl.style.height = "20px";
      flyingEl.style.opacity = "0.5";
    });
    setTimeout(() => flyingEl.remove(), 800);
  };

  const updateCart = () => {
    const cartItemCount = document.getElementById("cart-item-count");
    const cartTotalPrice = document.getElementById("cart-total-price");
    const cartCheckoutButton = document.getElementById("cart-checkout-button");

    cartContent.innerHTML = "";
    let total = 0,
      itemCount = 0;

    if (cartItems.length === 0) {
      cartContent.innerHTML =
        '<p class="cart__empty-message">Keranjang Anda kosong.</p>';
      if (cartCheckoutButton) cartCheckoutButton.style.display = "none";
    } else {
      cartItems.forEach((item) => {
        if (!item || !item.options) {
          console.warn("Skipping malformed cart item:", item);
          return;
        }

        const cartItemElement = document.createElement("div");
        cartItemElement.classList.add("cart__item");
        cartItemElement.dataset.id = item.id;
        cartItemElement.innerHTML = `
          <img src="${item.imageUrl}" alt="${item.name}" class="cart__item-img">
          <div class="cart__item-details">
            <h3 class="cart__item-name">${item.name}</h3>
            <div class="cart__item-options"><small>${item.options.sugar}, ${
          item.options.ice
        }</small></div>
            <span class="cart__item-price">${formatRupiah(
              item.price * item.quantity
            )}</span>
            <div class="cart__item-actions">
              <div class="cart__item-quantity-controls">
                <button class="cart__quantity-btn decrease-qty">-</button>
                <span class="cart__item-quantity">${item.quantity}</span>
                <button class="cart__quantity-btn increase-qty">+</button>
              </div>
              <i class="ri-delete-bin-line cart__item-remove"></i>
            </div>
          </div>`;
        cartContent.appendChild(cartItemElement);
        total += item.price * item.quantity;
        itemCount += item.quantity;
      });
      if (cartCheckoutButton) cartCheckoutButton.style.display = "block";
    }
    if (cartTotalPrice) cartTotalPrice.innerText = formatRupiah(total);
    if (cartItemCount) cartItemCount.innerText = itemCount;
    saveCart();
  };

  const addToCart = (product, options) => {
    const cartItemId = `${product.id}-${options.sugar.replace(
      " ",
      "-"
    )}-${options.ice.replace(" ", "-")}`;
    const existingItem = cartItems.find((item) => item.id === cartItemId);
    if (existingItem) {
      existingItem.quantity++;
    } else {
      cartItems.push({
        id: cartItemId,
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        options,
        quantity: 1,
      });
    }
    updateCart();
    showNotification(`${product.name} ditambahkan!`);
  };

  const openCustomizationModal = (product) => {
    currentProductForModal = product;
    const modalProductDetails = document.getElementById(
      "modal-product-details"
    );
    const sugarOptions = document.getElementById("sugar-options");
    const iceOptions = document.getElementById("ice-options");
    modalProductDetails.innerHTML = `
      <img src="${product.imageUrl}" alt="${
      product.name
    }" id="modal-product-image">
      <h3>${product.name}</h3>
      <span>${formatRupiah(product.price)}</span>`;
    sugarOptions.querySelector(".active")?.classList.remove("active");
    sugarOptions
      .querySelector('[data-value="Normal Sugar"]')
      .classList.add("active");
    iceOptions.querySelector(".active")?.classList.remove("active");
    iceOptions
      .querySelector('[data-value="Normal Ice"]')
      .classList.add("active");
    customizationModal.classList.add("show-modal");
  };

  const closeCustomizationModal = () =>
    customizationModal.classList.remove("show-modal");

  /*=============== FUNGSI SPESIAL & SKELETON (DIPINDAHKAN KE DALAM) ===============*/
  const specialSection = document.getElementById("special");

  function showSpecialSkeleton(container) {
    container.innerHTML = "";
    for (let i = 0; i < 2; i++) {
      const skeletonCard = document.createElement("div");
      skeletonCard.className = "special__card skeleton-card";
      skeletonCard.innerHTML = `
        <div class="special__content">
          <div class="skeleton skeleton-h3"></div>
          <div class="skeleton skeleton-p"></div>
          <div class="skeleton skeleton-btn"></div>
        </div>
        <div class="skeleton skeleton-img"></div>`;
      container.appendChild(skeletonCard);
    }
  }

  async function renderSpecials() {
    const specialContainer = document.querySelector(".special__container");
    if (!specialContainer) return;

    showSpecialSkeleton(specialContainer);

    try {
      const specialsSnapshot = await db.collection("specials").get();

      specialContainer.innerHTML = "";

      if (specialsSnapshot.empty) {
        if (specialSection) specialSection.style.display = "none";
        return;
      }

      specialsSnapshot.forEach((doc) => {
        const special = doc.data();
        const card = document.createElement("div");
        card.className =
          special.category === "matcha"
            ? "special__card matcha-special"
            : "special__card";
        card.innerHTML = `
          <div class="special__badge">Spesial!</div>
          <div class="special__content">
            <h3 class="special__name">${special.name}</h3>
            <p class="special__description">${special.description}</p>
            <a href="#products" class="button">Pesan Sekarang</a>
          </div>
          <img src="${special.imageUrl}" alt="${special.name}" class="special__img" />`;
        specialContainer.appendChild(card);
      });
    } catch (error) {
      console.error("TERJADI ERROR SAAT MENGAMBIL DATA SPESIAL:", error);
      specialContainer.innerHTML = `<p class="info-text">Gagal memuat menu spesial. Error: ${error.message}. Pastikan aturan Firestore sudah benar.</p>`;
    }
  }

  /*=============== MASTER EVENT LISTENER (EVENT DELEGATION) ===============*/
  document.addEventListener("click", (e) => {
    const target = e.target;

    if (target.closest("#cart-icon")) showCart();
    if (target.closest("#cart-close")) hideCart();

    if (target.closest(".products__filter-btn")) {
      document
        .querySelector(".products__filter-btn.active")
        .classList.remove("active");
      const btn = target.closest(".products__filter-btn");
      btn.classList.add("active");
      renderProducts(btn.dataset.filter);
      body.classList.toggle("matcha-theme", btn.dataset.filter === "matcha");
    }

    if (target.closest(".choose-options-btn")) {
      const card = target.closest(".products__card");
      if (card) {
        openCustomizationModal({
          id: card.dataset.id,
          name: card.dataset.name,
          price: parseFloat(card.dataset.price),
          imageUrl: card.dataset.imageUrl,
        });
      }
    }

    if (target.closest(".modal-close") || target === customizationModal)
      closeCustomizationModal();
    if (target.classList.contains("option-btn")) {
      const parent = target.closest(".options-container");
      parent.querySelector(".active")?.classList.remove("active");
      target.classList.add("active");
    }

    if (target.id === "modal-add-to-cart") {
      const selectedSugar = document.querySelector("#sugar-options .active")
        .dataset.value;
      const selectedIce = document.querySelector("#ice-options .active").dataset
        .value;
      addToCart(currentProductForModal, {
        sugar: selectedSugar,
        ice: selectedIce,
      });
      flyToCart(document.getElementById("modal-product-image"));
      closeCustomizationModal();
    }

    const cartItem = target.closest(".cart__item");
    if (cartItem) {
      const cartItemId = cartItem.dataset.id;
      const itemIndex = cartItems.findIndex((i) => i.id === cartItemId);
      if (itemIndex === -1) return;
      if (target.classList.contains("increase-qty")) {
        cartItems[itemIndex].quantity++;
        updateCart();
      } else if (target.classList.contains("decrease-qty")) {
        cartItems[itemIndex].quantity--;
        if (cartItems[itemIndex].quantity <= 0) cartItems.splice(itemIndex, 1);
        updateCart();
      } else if (target.classList.contains("cart__item-remove")) {
        cartItem.classList.add("removing");
        setTimeout(() => {
          cartItems.splice(itemIndex, 1);
          updateCart();
          showNotification("Item dihapus.");
        }, 400);
      }
    }

    if (target.closest(".mobile-nav__link")) {
      if (window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }

    if (target.id === "cart-checkout-button" && cartItems.length > 0) {
      window.location.href = `checkout.html?items=${encodeURIComponent(
        JSON.stringify(cartItems)
      )}`;
    }
  });

  /*=============== UI SETUP & SCROLL-BASED LOGIC ===============*/
  const sections = document.querySelectorAll("section[id]");
  const allNavLinks = document.querySelectorAll(
    ".nav__link, .mobile-nav__link"
  );
  const mobileNav = document.getElementById("mobile-nav");
  const mobileNavIndicator = document.querySelector(".mobile-nav__indicator");
  let lastScrollY = window.scrollY;

  const scrollActive = () => {
    const scrollY = window.scrollY;

    if (mobileNav) {
      if (scrollY > lastScrollY && scrollY > 200)
        mobileNav.classList.add("hide");
      else mobileNav.classList.remove("hide");
      lastScrollY = scrollY <= 0 ? 0 : scrollY;
    }

    let currentSectionId = "";
    sections.forEach((current) => {
      const sectionHeight = current.offsetHeight;
      const sectionTop =
        current.offsetTop -
        (window.innerWidth >= 769 ? 70 : window.innerHeight / 2);
      if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
        currentSectionId = current.getAttribute("id");
      }
    });

    allNavLinks.forEach((link, index) => {
      const isActive = link.getAttribute("href") === `#${currentSectionId}`;
      link.classList.toggle("active-link", isActive);

      if (isActive && link.closest(".mobile-nav")) {
        const linkIndex = Array.from(mobileNav.children).indexOf(link) - 1;
        if (mobileNavIndicator) {
          mobileNavIndicator.style.transform = `translateX(${
            linkIndex * 100
          }%)`;
        }
      }
    });
  };

  window.addEventListener("scroll", scrollActive, { passive: true });
  window.addEventListener(
    "scroll",
    () => {
      document
        .getElementById("header")
        .classList.toggle("shadow-header", window.scrollY >= 50);
      document
        .getElementById("scroll-up")
        .classList.toggle("show-scroll", window.scrollY >= 350);
    },
    { passive: true }
  );

  const footer = document.getElementById("footer");
  const footerNamesContainer = document.querySelector(".footer__names");
  const glowLine = document.querySelector(".footer__glow-line");
  if (footer && footerNamesContainer && glowLine) {
    footerNamesContainer.addEventListener("mouseleave", () => {
      glowLine.style.width = "0px";
    });

    footerNamesContainer.querySelectorAll(".footer__name").forEach((name) => {
      name.addEventListener("mouseenter", () => {
        const rect = name.getBoundingClientRect();
        const containerRect = footerNamesContainer.getBoundingClientRect();
        glowLine.style.width = `${rect.width}px`;
        glowLine.style.transform = `translateX(${
          rect.left - containerRect.left
        }px)`;
      });
    });
  }

  /*=============== INITIAL LOAD ===============*/
  renderProducts();
  renderSpecials(); // Panggil fungsi yang sudah ada di dalam scope
  updateCart();
  scrollActive();

  /*=============== SCROLL REVEAL ANIMATION ===============*/
  const sr = ScrollReveal({
    origin: "bottom",
    distance: "80px",
    duration: 2500,
    delay: 200,
    reset: false,
    easing: "cubic-bezier(0.5, 0, 0, 1)",
  });
  sr.reveal(".special__card", {
    delay: 400,
    origin: "left",
    distance: "100px",
    interval: 100,
  });
  sr.reveal(".products__filter-btn", { interval: 100, origin: "top" });
  sr.reveal(".products__card", { interval: 100, origin: "top" });
}); // AKHIR DARI BLOK "DOMContentLoaded"

/*=============== SERVICE WORKER REGISTRATION ===============*/
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./sw.js")
      .then((registration) =>
        console.log("Service Worker registered:", registration)
      )
      .catch((error) =>
        console.log("Service Worker registration failed:", error)
      );
  });
}
